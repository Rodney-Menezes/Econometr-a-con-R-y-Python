#==================================================
#==================================================
# Curso: Econometría aplicada utilizando R y Python
#==================================================
#==================================================
#Instructor: Jose Rodney Menezes De la Cruz
#==================================================
# Sesion 2.  Introducción a Python
#------------------------------------------------
#------------------------------------------------



#Los números:
#------------

#Suma
2+3

#resta
3-2
2-3

#Division
4/2
3/2

#multiplicación
5*2

#Modulo
3%2

#creamos una variable:
n = 3
print(n)
n+4
n*2

#potencia
n**2

#crear otra variable
m=8
n+m
m**n
m

m=5
n=10
print(m,n)

dos_n = 6
dos_n



#Los textos
#-----------

"hola mundo" 

'quiero escribir "hola mundo" '

"quiero escribir 'hola mundo'"

"quiero escribir \"hola mundo\" "

'quiero escribir \'hola mundo\' '

"una cadena"
"otra cadena"
"otra cadena mas"

print("una cadena")
print("otra cadena")
print("otra cadena mas")

print("""una cadena
otra cadena
otra cadena mas""")

print("una cadena \notra cadena \notra cadena mas")

print("una cadena \totra cadena \totra cadena mas") 

print("C:documentos\numeros")

print(r"C:documentos\numeros")

m = "un texto"
m

n = " otro texto"
n

m+n

z =n*10
z
z + m

C1 = "una cadena \notra cadena \notra cadena mas"
C1
print(C1)



# Las listas
#------------

#Indices y slicing

palabra = "Python"
palabra

palabra[5]
palabra[-1]
palabra[-6]
palabra[2:5]
palabra[2:]
palabra[:]

palabra[0]= "N"
palabra = "N"+ palabra[1:]
palabra



#listas

n = [1,2,3,4]
n
n[-1]

m = [5,6,7]
m

z=n+m
z
z[2:6]

pares = [2,4,6,9,12,14]
pares[3]=10
pares[1:4]= [1,2,3,8] 
pares
len(pares)
pares.append(16)
pares

a = [0,1,2]
b = [3,4,5]
c = [6,7,8]

z = [a,b,c]
z[0:1]
z[1][2]
z



# El tipo lógico
#---------------

#Representa la mínima expresión racional: Verdadero (True) y Falso (False)
1+1 == 3
1+1 == 2



# Los operadores relacionales
#------------------------------
#Sirven para comparar dos valores, dependiendo del resultado de la comparación 
#pueden devolver: Verdadero (True), si es cierta y Falso (False), si no es cierta

# Igual que
3 == 2

# Distinto de
3 != 2

# Mayor que
3 > 2

# Menor que
3 < 2

# Mayor o igual que
3 >= 4

# Menor o igual que
3 <= 4

#También podemos comparar variables
a = 10
b = 5
a > b
b != a
a == b*2

#Y otros tipos, como cadenas, listas, el resultado de algunas funciones o los 
#propios tipos lógicos
"Hola" == "Hola"
"Hola" != "Hola"

c = "Hola"
c[0] == "H"
c[-1] == "a"

l1 = [0,1,2]
l2 = [2,3,4]
l1 == l2

len(l1) == len(l2)
l1[-1] == l2[0]

True == True
False == True
False != True
True > False
False > True

#La representación aritmética de True y False equivale a 1 y 0 respectivamente
True * 3
False / 5
True * False



#Operadores lógicos
#-------------------

# Not - Negación lógica
not True
not True == False

# And - Conjunción lógica
True and True
True and False
False and True
False and False
a = 45
a > 10 and a < 20
c = "Hola Mundo"
len(c) >= 20 and c[0] == "H"

# Or - Disyunción lógica
True or True
True or False
False or True
False or False
c = "SALIR"
c == "EXIT" or c == "FIN" or c == "SALIR"
c = "Lector"
c[0] == "H" or c[0] == "h"

#Expresiones anidadas
#Se pueden solucionar empleando las reglas de precedencia:
#Primero los paréntesis porque tienen prioridad
#Segundo, las expresiones aritméticas por sus propias reglas
#Tercero, las expresiones relacionales
#Cuarto, las expresiones lógicas
a = 10
b = 5
a * b - 2**b >= 20 and not (a % b) != 0



#Las Tuplas
#-----------
#Son unas colecciones parecidas a las listas, con la peculiaridad de que son inmutables
tupla = (100,"Hola",[1,2,3],-50)
tupla

#Indexación y slicing
tupla[0]
tupla[-1]
tupla[2:]
tupla[2][-1]

#Inmutabilidad
tupla[0] = 50

#Función len()
len(tupla)
len(tupla[2])

#index(): Sirve para buscar un elemento y saber su posición en la tupla.
tupla.index(100)
tupla
tupla.index('Hola')
tupla.index('Otro')

#count(): Sirve para contar cuantas veces aparece un elemento en una tupla.
tupla.count(100)
tupla.count('Algo')
tupla = (100,100,100,50,10)
tupla.count(100)

#append(): Al ser inmutables, las tuplas no disponen de métodos para modificar su contenido.
tupla.append(10)



#Los diccionarios
#----------------
#Se basan en una estructura mapeada donde cada elemento de la colección se encuentra 
#identificado con una clave única. 
vacio = {}
vacio

#Tipo de una variable
type(vacio)

#Definición
colores = {'amarillo':'yellow','azul':'blue'}
len(colores)
colores['verde'] = 'green'
colores
len(colores)
colores['azul']
colores['amarillo']
numeros = {10:'diez',20:'veinte'}
numeros[10]

#Modificación de valor a partir de la clave
colores['amarillo'] = 'white'
colores

#Función del()
del(colores['azul'])
colores



# Las funciones
#--------------

#Definición y llamada
def saludar():
    print("Hola! Este print se llama desde la función saludar()")
saludar()

#Ámbito de las variables
def test():
    n = 10
test()
print(n)

#Sin embargo, una variable declarada fuera de la función (al mismo nivel), 
#sí que es accesible desde la función:
m = 10
def test():
    print(m)
test()

#Siempre que declaremos la variable antes de la ejecución, podemos acceder a 
#ella desde dentro:
def test():
    l=15
    print(l)
test()
#test()
l = 10
test()
#Por tanto no podemos modificar una variable externa dentro de una función.

#Retorno de valores
def test():
    return 10
test()

def test():
    return [1,2,3,4,5]
test()

def test():
    return "Una cadena",20,[1,2,3]
test()

#Argumentos por posición
def resta(a,b):
    return a-b
resta(1,2)   # posición índice 0 valor 1, posición índice 1 valor 2

#Argumentos por nombre
resta(b=2,a=1)



#Paso por valor y paso por referencia:
#------------------------------------

#Ejemplo paso por valor
def doblar_valor(numero):
    numero*=2
 
n = 10
doblar_valor(n)
n

#Ejemplo paso por referencia
def doblar_valores(numeros):
    for i,n in enumerate(numeros):
        numeros[i] *= 2
        
ns = [10,50,100]
doblar_valores(ns)
ns



#Funciones Integradas
#--------------------

#Ejemplo 1
def cuenta_atras(num):
    num -= 1
    if num > 0:
        print(num)
        cuenta_atras(num)
    else:
        print("Boooooooom!")
        
cuenta_atras(5)

#Ejemplo 2
def factorial(num):
    print("Valor inicial ->",num)
    if num > 1:
        num = num * factorial(num -1)
    print("valor final ->",num)
    return num

factorial(5)



#Bucles:
#-------

#While
i = 1
while i < 6:
  print(i)

i = 1
while i < 6:
  print(i)
  if i == 3:
    break
  i += 1

i = 1
while i < 6:
  print(i)
  i += 1
else:
  print("i is no longer less than 6")

#for:
nums = [4, 78, 9, 84]
for n in nums:
    print(n)

for i in range(11):
    print(i)

for num in range(0, 11, 2):
    print(num)
    
def longitud(mi_lista):
    cont = 0
    for _ in mi_lista:
        cont += 1
    return cont

coleccion = [2, 4, 5, 7, 8, 9, 3, 4]
for e in coleccion:
    if e == 7:
        break
    print(e)

for e in iterable:
    # Tu código aquí
else:
    # Este código siempre se ejecuta si no
    # se ejecutó la sentencia break en el bloque for


