#===========================================
#===========================================
# Curso: Econometría aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 8. multicolinealidad
#-------------------------------------------
#-------------------------------------------

#librerias
import numpy as np #para Análisis numérico
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos
import statsmodels.api as sm  #para Construcción de los modelos y realización de las estimaciones

# Cargar base de datos
ruta = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_8\\consumo_fun.xlsx"
data8 = pd.read_excel(ruta, header=0)
data8.columns

# Creacion  de nuevas variables
x1 = np.log(data8['RQR'])
x2 = data8['ltcr']/data8['lcpr']
# Uniendo las variables a la base de datos
data8 = data8.assign(lRQR = x1.values)
data8 = data8.assign(ltceer = x2.values)

#Resumenes estadisticos
data8.describe()

# Visualizamos rápidamente las caraterísticas de entrada
data8.hist()
plt.show()


#Estimar los coeficientes del modelo de regresión múltiple: 
#----------------------------------------------------------
#eliminamos los valores perdidos
data8 = data8.dropna()

#Separamos la varibale dependiente de las independientes:
Y1 = data8["lcpr"]
X1 = data8[["lrqr", "ltcr", "lydr"]]

# Creamos el objeto de Regresión Linear:
MiModelo1 = sm.OLS(Y1, sm.add_constant(X1))

#guardamos la estimacion del modelos
Resultados1 = MiModelo1.fit()

#mostramos el resultados del modelo
Resultados1.summary()

#coeficiente de correlacion
VRelevant = data8[["lcpr", "lrqr", "ltcr", "lydr"]]
VRelevant.corr()

#Grafica de la matriz de correlacion
plt.matshow(VRelevant.corr())
