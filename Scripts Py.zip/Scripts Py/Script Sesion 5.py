#===========================================
#===========================================
# Curso: Econometría aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 5. El modelo de regresión multiple 
#-------------------------------------------
#-------------------------------------------

#cargando paquetes
 
import numpy as np #para Análisis numérico
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos
import statsmodels.api as sm  #para Construcción de los modelos y realización de las estimaciones

#poniendo cemilla
np.random.seed(42)

# Importando datos 
ruta = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_5\\Sesion5_datos.xls"
data5 = pd.read_excel(ruta, header=1, nrows=81)

#Cambiar nombres de variables
data5.columns
data5 = data5.rename(columns={'Indicadores económicos de coyuntura > Precios e inflación > Índice nacional de precios al consumidor > Mensual > Índice Índice general a/  f2/ (Base segunda quincena de diciembre 2010 = 100) ':'inflacion',
                                   'Indicadores económicos de coyuntura > Indicadores del sector manufacturero (EMIM) > Series originales > Índice de las remuneraciones medias reales por persona ocupada > Índice > Total Total de la industria manufacturera p1 / f1/ (Índice base 2008 = 100) ':'IsecManufc',
                                   'Índice(Índice base 2003 = 100) ':'Indice'})
data5.columns

# Ahora veamos algunas estadísticas de nuestros datos
data5.describe() #todo el dataset
data5['INPC'].describe() #solo una variable variables
data5[['INPC', 'REMPO']].describe() #solo algunas variables

# Visualizamos rápidamente las caraterísticas de entrada
data5.hist()
plt.show()


#Estimar los coeficientes del modelo de regresión múltiple: 

#eliminamos los valores perdidos
data5 = data5.dropna()

#separamos la varibale dependiente de las independientes
Y = data5["VENTAS"]
X = data5[["INPC", "REMPO", "LPR", "LVENTA", "LINGR"]]

# Creamos el objeto de Regresión Linear
MiModelo = sm.OLS(Y, sm.add_constant(X))

#guardamos las estimaciones del modelo
Resultados = MiModelo.fit()

#mostramos los resultados del modelo
Resultados.summary()
    
