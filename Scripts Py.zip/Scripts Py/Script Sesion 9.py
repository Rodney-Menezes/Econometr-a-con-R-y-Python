#===========================================
#===========================================
# Curso: Econometría aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 9. Hetrerocedasticidad
#-------------------------------------------
#-------------------------------------------

#librerias
import numpy as np #para Análisis numérico
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos
import statsmodels.api as sm  #para Construcción de los modelos y realización de las estimaciones y tests
from statsmodels.formula.api import ols #para analisis ANOVA

# Cargar base de datos
ruta = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_9\\NumCajas.xlsx"
data9 = pd.read_excel(ruta, header=0)
data9.columns

#Resumenes estadisticos
data9.describe()

# Visualizamos rápidamente las caraterísticas de entrada
data9.hist()
plt.show()

#eliminamos los valores perdidos
data9 = data9.dropna()


#Estimar los coeficientes del modelo de regresión múltiple: 
#----------------------------------------------------------

model = ols('Tiempo ~ Cajas + Distancia', data=data9).fit()

#mostramos el resultados del modelo
model.summary()


#Matriz de correlación
data9.corr()

#Grafica de la matriz de correlacion
plt.matshow(data9.corr())

# Analisis ANOVA
anova_table = sm.stats.anova_lm(model)
anova_table

#Graficas del modelo:
plt.figure()
plt.hist(model.resid)
plt.title('Histograma del modelo')
plt.show()

plt.figure()
plt.boxplot(model.resid)
plt.title('Grafico de caja del modelo')
plt.show()

plt.figure()
sm.graphics.qqplot(model.resid)
plt.title('Grafico de caja del modelo')
plt.show()


#Prueba de Breusch-Pagan para la heterocedasticidad:
sm.stats.diagnostic.het_breuschpagan(model.resid, exog_het=data9[['Cajas', 'Tiempo']])

