#===========================================
#===========================================
# Curso: Econometría aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 7. Normalidad
#-------------------------------------------
#-------------------------------------------


#librerias
import numpy as np #para Análisis numérico
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos
import statsmodels.api as sm  #para Construcción de los modelos y realización de las estimaciones y tests
from scipy import stats #para el test de jarque bera

# Cargar base de datos
ruta1 = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_7\\Elast.csv"
ruta2 = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_7\\Gasolina.csv"
colnames1 = ['OBS', 'DRel', 'PRel', 'PIB']
colnames2 = ['Año','G','Pobl','Pg','Y','Pan','Pau','Ptp','Pd','Pnd','Ps'] 

Elast = pd.read_csv(ruta1, names=colnames1, skiprows=1)
Elast.columns

Gasolina = pd.read_csv(ruta2, names=colnames2, skiprows=1)
Gasolina.columns

# Creandon nuevas variables
# para el data set Elast:
x1 = np.log(Elast['DRel'])
x2 = np.log(Elast['PRel'])
x3 = np.log(Elast['PIB'])
# Uniendo las variables a la base de datos
Elast = Elast.assign(LogDRel = x1.values)
Elast = Elast.assign(LogPRel = x2.values)
Elast = Elast.assign(LogPBI = x3.values)
# para el dataset Gasolina:
x4 = np.log(Gasolina['G']/Gasolina['Pobl'])
x5 = np.log(Gasolina['Y'])
x6 = np.log(Gasolina['Pg'])
x7 = np.log(Gasolina['Pan'])
# Uniendo las variables a la base de datos
Gasolina = Gasolina.assign(LogGPob = x4.values)
Gasolina = Gasolina.assign(LogY = x5.values)
Gasolina = Gasolina.assign(LogPg = x6.values)
Gasolina = Gasolina.assign(LogPan = x7.values)

#Resumenes estadisticos
Elast.describe()
Gasolina.describe()

# Visualizamos rápidamente las caraterísticas de entrada
Elast.hist()
plt.show()

Gasolina.hist()
plt.show()


#Estimar los coeficientes del modelo de regresión múltiple: 

#eliminamos los valores perdidos
Elast = Elast.dropna()
Gasolina = Gasolina.dropna()

#Separamos la varibale dependiente de las independientes:
#Para la base de datos Elast
Y1 = Elast["LogDRel"]
X1 = Elast[["LogPRel", "LogPBI"]]
#Para la base de datos Gasolina
Y2 = Gasolina["LogGPob"]
X2 = Gasolina[["LogY", "LogPg", "LogPan"]]

# Creamos el objeto de Regresión Linear:
#para base de datos Elast
MiModelo1 = sm.OLS(Y1, sm.add_constant(X1))
#para base de datos Gasolina
MiModelo2 = sm.OLS(Y2, sm.add_constant(X2))

#guardamos las estimaciones de los modelos
Resultados1 = MiModelo1.fit()
Resultados2 = MiModelo2.fit()

#mostramos los resultados de los modelos
Resultados1.summary()
Resultados2.summary()

#Tests de Jarque Bera:
# modelo 1
stats.jarque_bera(Resultados1.resid)
# modelo 2 
stats.jarque_bera(Resultados2.resid)

#Graficas:
# del modelo 1:
plt.figure()
plt.hist(Resultados1.resid)
plt.title('Histograma del modelo 1')
plt.show()
# del modelo 2:
plt.figure()
plt.hist(Resultados2.resid)
plt.title('Histograma del modelo 2')
plt.show()

