#===========================================
#===========================================
# Curso: Econometría aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 13. El modelo VAR 
#-------------------------------------------
#-------------------------------------------

#librerias
import numpy as np #para Análisis numérico
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos
import statsmodels.api as sm  #para Construcción de los modelos y realización de las estimaciones
from statsmodels.tsa.api import VAR #para el VAR
from statsmodels.formula.api import ols  #para MCO
from statsmodels.tsa.stattools import grangercausalitytests #para causalidad de granger
from scipy import stats #para el test de jarque bera

# Cargar base de  y dar formato de series de tiempo
ruta = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_13\\base_var_inflacion.csv"
data13 = pd.read_csv(ruta)

#creando una columna vacia
data13 = data13.assign(year="")

# Damos formato de series de tiempo
data13['year']  = pd.date_range(start='1980/01', end='1994/09', freq='M')

# Creandon nuevas variables
x1 = np.log(data13['M2'])
x2 = np.log(data13['INPC'])
# Uniendo las variables a la base de datos
data13 = data13.assign(LogM2 = x1.values)
data13 = data13.assign(LogPg = x2.values)

data13.columns
data13.index

#Grafico
data13[['LogM2', 'LogPg']].plot()

#Prueba ADF 
sm.tsa.stattools.adfuller(data13['LogM2'] , maxlag = None, regression = 'c' #{"c", "ct", "ctt", "nc"}
                                   , autolag = 'AIC' #{"AIC", "BIC", "t-stat", None} 
                                   , store = False , regresults = False )
sm.tsa.stattools.adfuller(data13['LogPg'], maxlag = None, regression = 'c' #{"c", "ct", "ctt", "nc"}
                                   , autolag = 'AIC' #{"AIC", "BIC", "t-stat", None} 
                                   , store = False , regresults = False )

#Crear variables en primeras diferencias 
d1LogM2 = data13['LogM2'].diff() 
d1LogPg =data13['LogPg'].diff()

#Crear variables en segundas diferencias 
d2LogM2 = d1LogM2.diff()
d2LogPg =d1LogPg.diff()

#debemos eliminar los Nan
d2LogM2=d2LogM2.dropna() 
d2LogPg=d2LogPg.dropna()

#Prueba ADF en 2 diferencias
sm.tsa.stattools.adfuller(d2LogM2 , maxlag = None, regression = 'c' #{"c", "ct", "ctt", "nc"}
                                   , autolag = 'AIC' #{"AIC", "BIC", "t-stat", None} 
                                   , store = False , regresults = False )

sm.tsa.stattools.adfuller(d2LogPg, maxlag = None, regression = 'c' #{"c", "ct", "ctt", "nc"}
                                   , autolag = 'AIC' #{"AIC", "BIC", "t-stat", None} 
                                   , store = False , regresults = False )


#Grafico
plt.plot(d2LogM2, 'r')
plt.show()

plt.plot(d2LogPg)
plt.show()


#unimos bases
baseVar = pd.DataFrame([d2LogM2, d2LogPg])
baseVar = baseVar.transpose()
baseVar.columns


# test de Causalidad de Granger:

#La causalidad de la oferta monetaria hacia los precios.
sm.tsa.stattools.grangercausalitytests(baseVar[['LogPg', 'LogM2']], maxlag = 1, addconst = True , verbose = True)
#La causalidad de los precios hacia la oferta monetaria. 
sm.tsa.stattools.grangercausalitytests(baseVar[['LogM2', 'LogPg']], maxlag = 1, addconst = True , verbose = True)


#Estimacion exploratorio del VAR
model = VAR(baseVar)
for i in range(12):
    result = model.fit(i)
    print('Lag Order =', i)
    print('AIC : ', result.aic)
    print('BIC : ', result.bic)
    print('FPE : ', result.fpe)
    print('HQIC: ', result.hqic, '\n')

#VAR de pedido seleccionado
modelVAR = model.fit(4)
modelVAR.summary()

#Grafico de la variable observado vs la estimada del Modelo VAR
modelVAR.plot()

# test de autocorrelacion
sm.stats.durbin_watson(modelVAR.resid)

#Tests de Jarque Bera:
stats.jarque_bera(modelVAR.resid)

#Funcion Impulso Respuesta
VARirf = modelVAR.irf(10)
VARirf.irfs

#Grafico de la Funcion Impulso Respuesta
VARirf.plot(impulse='LogM2')
#efectos acumulativos
VARirf.plot_cum_effects()

#descomposicion de la Varianza
fevd = modelVAR.fevd(10)
fevd.summary()
fevd.plot()
