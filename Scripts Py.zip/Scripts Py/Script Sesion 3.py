#===========================================
#===========================================
# Curso: Econometría aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 3. AE y limpieza de datos 
#-------------------------------------------
#-------------------------------------------



#librerias
#-----------
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos

# Cargar base de datos
#----------------------
rutaA = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\autos.csv"
rutaB = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\diamantes.csv"
rutaC = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\vuelos.csv"
rutaD = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\tablapy.xlsx"
 

data3a = pd.read_csv(rutaA, header=0)
data3b = pd.read_csv(rutaB, header=0)
data3c = pd.read_csv(rutaC, header=0)
tabla = pd.read_excel(rutaD, header=0)


#visualizacion de datos:
#-----------------------
data3a['cilindrada']

#creando graficos con matplotlib:
#--------------------------------

# Algunas notas sobre pyplot:
#.............................

# Colores
#........
#Símbolo   Color

# “b”      Azul
# “g”      Verde
# “r”      Rojo
# “c”      Cian
# “m”      Magenta
# “y”      Amarillo
# “k”      Negro
# “w”      Blanco

# Marcas y lineas
#.................
#Símbolo      Descripción

# “-“         Línea continua
# “–”         Línea a trazos
# “-.”        Línea a puntos y rayas
# “:”         Línea punteada
# “.”         Símbolo punto
# “,”         Símbolo pixel
# “o”         Símbolo círculo relleno
# “v”         Símbolo triángulo hacia abajo
# “^”         Símbolo triángulo hacia arriba
# “<”         Símbolo triángulo hacia la izquierda
# “>”         Símbolo triángulo hacia la derecha
# “s”         Símbolo cuadrado
# “p”         Símbolo pentágono
# “*”         Símbolo estrella
# “+”         Símbolo cruz
# “x”         Símbolo X
# “D”         Símbolo diamante
# “d”         Símbolo diamante delgado


plt.plot(data3a['cilindrada'], data3a['autopista'], 'o')
plt.show()


plt.plot(data3a['cilindrada'], data3a['autopista'], 'ro')
plt.show()

plt.scatter('cilindrada', 'autopista',c='cilindros', data=data3a)
plt.show()

plt.scatter('cilindrada', 'autopista',c='cilindros', s='anio',  data=data3a)
plt.show()

# Filtrar filas:
#---------------

#Filtrado en base al valor de una columna
ene1 = data3c['mes'] == 1 #solo devuelve True o False
dic25 = data3c[data3c['mes'] == 12] #devuelve el filtro que queremos

#Filtrado de las columnas que no tienen un valor
NoOct = data3c[data3c['mes'] != 10] #devuelve el filtro que queremos

#Filtrado en base a valores nulos
data3c = data3c[data3c.mes.isnull()] #para solo tener valores Nan
data3c = data3c[data3c.mes.notnull()] #para NO tener valores Nan 

#otra forma de eliminar valores perdidos
data3c = data3c.dropna()


#Filtrados por elementos en una lista
data3c = data3c[data3c.mes.isin([12, 10])]

#Unión de varias condiciones
data3c[data3c.mes.isin([12, 10]) & data3c.mes.notnull()] #& and, | or
data3c[data3c.mes.isin([12, 10]) & data3c.dia.isin([25, 30])]


# Añadir nuevas variables: 
#-------------------------
# Creacion  de nuevas variables
X = data3c['horario_salida'] - data3c['horario_llegada'] 
# Uniendo las variables a la base de datos
data3c = data3c.assign(retraso = X.values)
data3c.columns

#cambiar normabres de variables
data3c.rename(columns={'codigo_cola':'cola_num',
                        'aerolinea':'empresa'},
               inplace=True)

#eliminar variables
data3c.drop(['empresa'], axis=1, inplace= True)


#Ordenamiento de datos:
#-----------------------
tabla.columns

#Caso 1:
#.......
#A menudo queremos mantener las columnas de identificador como están 
#(index=["student", "school"]), pero pivotear o "dividir" los valores de una 
#columna (values="grade") en función de otra columna (columns="class"). 

tydi1 = tabla.pivot_table(index=["student", "school"], 
                    columns='cLasS', 
                    values='gRaDe')
#Cada valor único en la columna de la clase será una nueva columna 
#(english, math, physics) en el marco de datos amplio / dinámico. 
#También podemos proporcionar una lista para el parámetro de columns.
#Para deshacerse del índice múltiple, use reset_index ().

#Caso 2:
#.......
#También puede agregar cada fila y columna resultante especificando 
#margins=True (default False)

tydi2 = tabla.pivot_table(index=["student", "school"], 
                    columns='cLasS', 
                    values='gRaDe',
                    margins=True,  # add margins
                    aggfunc='sum')  # sum margins (rows/columns)

#Aquí agregamos calculando la suma a través de aggfunc='sum' (default 'mean').
#Hay muchas otras funciones de agregación que puede usar (e.g.,'median' 'sum' 'max'). 
#También puede especificar varias funciones como una lista (e.g.,aggfunc=['mean', 'sum']).

#Caso 3:
#.......
#Si no especificamos ninguna columna a través de columnas, todas las columnas numéricas que 
#no sean de identificación restantes (solo la calificación en este marco de datos) 
#se pivotarán (de largo a ancho).
tydi3 =tabla.pivot_table(index=["student", "school"])
#En los datos largos originales, cada estudiante tiene cuatro calificaciones 
#(english, math, physics), sin embargo, en el pivot_table del ejemplo anterior, 
#cada estudiante solo tiene una calificación después de pivotar.
#¿Por qué y cómo funciona? Si recuerda el ejemplo anterior, el valor predeterminado es 
#aggfunc = 'mean'. Por lo tanto, lo que hizo la función fue agrupar los datos por 
#estudiante y escuela (a través del index=["student", "school"]) y calcular el 
#valor medio de cada grupo.


#Merge:
#--------

#Data frames:
df1 = pd.DataFrame({"Ciudad":['New York', 'Chicago', 'Orlando'], 
                   "temperatura":[21,14,35]})
df1

df2 = pd.DataFrame({"Ciudad":['Chicago', 'New York', 'Orlando'], 
                   "humedad":[65,68,75]})
df2

#merge tipo 1:
df3 = pd.merge(df1, df2, on='Ciudad')
df3

#merge tipo 2:
df1 = pd.DataFrame({"Ciudad":['New York', 'Chicago', 'Orlando', 'baltimore'], 
                   "temperatura":[21,14,35,32]})
df1

df2 = pd.DataFrame({"Ciudad":['Chicago', 'Orlando', 'San Francisco'], 
                   "humedad":[65,68,75]})
df2

df3 = pd.merge(df1, df2, on='Ciudad')
df3

#merge tipo 3:
df1 = pd.DataFrame({"Ciudad":['New York', 'Chicago', 'Orlando', 'baltimore'], 
                   "temperatura":[21,14,35,32]})
df1

df2 = pd.DataFrame({"Ciudad":['Chicago', 'Orlando', 'San Francisco'], 
                   "humedad":[65,68,75]})
df2

df3 = pd.merge(df1, df2, on='Ciudad', how='inner') #por defecto
df3

df3 = pd.merge(df1, df2, on='Ciudad', how='outer')
df3

#merge tipo 4:
df3 = pd.merge(df1, df2, on='Ciudad', how='left')
df3

#merge tipo 5:
df3 = pd.merge(df1, df2, on='Ciudad', how='right')
df3


#merge tipo 5:
df3 = pd.merge(df1, df2, on='Ciudad', indicator='True')
df3

