#===========================================
#===========================================
# Curso: Econometría aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 16. Modelos Panel
#-----------------------------
#-----------------------------


#Instalar librerias
#pip install linearmodels

#librerias
import numpy as np #para Análisis numérico
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos
import statsmodels.api as sm  #para Construcción de los modelos y realización de las estimaciones
import linearmodels.panel as lpnl #para los modelos de panel

# Cargar base de datos
ruta = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_16\\InfDesmp.csv"
data16 = pd.read_csv(ruta, header=0)
data16.columns

#Resumenes estadisticos
data16.describe()

# Visualizamos rápidamente las caraterísticas de entrada
data16.hist()
plt.show()

#Indexamos las variables 
data16 = data16.set_index(['Periodo', 'Ciudad'])

#eliminamos variables
data16.drop(['Unnamed: 0'], axis=1, inplace= True)
data16.drop(['Nom_Ciudad'], axis=1, inplace= True)


#Regresion Pooled
#Pooled es simplemente OLS que comprende varias estructuras de datos de panel.
model = lpnl.PooledOLS(data16['INF'], data16[['U_UN', 'CETES28']])
pooled1 = model.fit()
print(pooled1)

#Efectos Fijos:
model2a = lpnl.PanelOLS(data16['INF'], data16[['U_UN']], entity_effects=True) #E. invariantes en el tiempo
model2b = lpnl.PanelOLS(data16['INF'], data16[['U_UN']], entity_effects=True, time_effects=True) #E.en el tiempo
EfecF1 = model2a.fit()
EfecF2 = model2b.fit()
print(EfecF1)
print(EfecF2)


#Efectos aleatorios
model3 = lpnl.RandomEffects(data16['INF'], data16[['U_UN', 'CETES28']])
EfecA = model3.fit()
print(EfecA)

#descomposicion de la varianza
EfecA.variance_decomposition

#El coeficiente θi determina cuánto se produce la degradación. Cuando este valor es 1, 
#el modelo RE se reduce al modelo agrupado, ya que esto ocurre cuando no hay varianza 
#en los efectos
EfecA.theta.head()

#comparacion de modelos
print(lpnl.compare({"Pooled":pooled1, "EF":EfecF1, "EA":EfecA}))
