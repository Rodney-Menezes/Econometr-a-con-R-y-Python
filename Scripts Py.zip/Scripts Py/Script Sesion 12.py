#==================================================
#==================================================
# Curso: Econometría aplicada utilizando R y Python
#==================================================
#==================================================
#Instructor: Jose Rodney Menezes De la Cruz
#==================================================
# Sesion 12. Cointegracion
#------------------------------------------------
#------------------------------------------------


#Instalar librerias
#pip install pmdarima

#Cargar librerias
import numpy as np #para Análisis numérico
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos
import statsmodels.api as sm  #para Construcción de los modelos y realización de las estimaciones y tests
from statsmodels.formula.api import ols
import statsmodels.tsa.vector_ar as smv
from scipy import stats
from statsmodels.tsa.arima.model import ARIMA
from pmdarima.arima import auto_arima


# Cargar base de  y dar formato de series de tiempo
ruta = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_12\\Consumo.csv"
data12 = pd.read_csv(ruta, index_col=0)

#mostramos las primeras lineas
data12.head(5)
#mostramos las ultimas lineas
data12.tail(4)

data12.columns
data12.index

#Grafico
data12[['CP', 'PIB_Mex']].plot()

#Prueba ADF 
sm.tsa.stattools.adfuller(data12['CP'] , maxlag = None, regression = 'c' #{"c", "ct", "ctt", "nc"}
                                   , autolag = 'AIC' #{"AIC", "BIC", "t-stat", None} 
                                   , store = False , regresults = False )
sm.tsa.stattools.adfuller(data12['PIB_Mex'], maxlag = None, regression = 'c' #{"c", "ct", "ctt", "nc"}
                                   , autolag = 'AIC' #{"AIC", "BIC", "t-stat", None} 
                                   , store = False , regresults = False )

#Crear variables en primeras diferencias 
d1CP = data12['CP'].diff() 
d1PBI =data12['PIB_Mex'].diff()

#debemos eliminar los Nan
d1CP=d1CP.dropna() 
d1PBIg=d1PBI.dropna()

#Grafico
plt.plot(d1CP, 'r')
plt.show()

plt.plot(d1PBI)
plt.show()


# test de Causalidad de Granger:
#La causalidad de CP hacia PBI_Mex
sm.tsa.stattools.grangercausalitytests(data12[['PIB_Mex', 'CP']], maxlag = 1, addconst = True , verbose = True)

# Análisis de cointegración de Johansen-Joselius:
#statsmodels.tsa.vector_ar.vecm.coint_johansen( endog , det_order , k_ar_diff )
johansen1 = smv.vecm.coint_johansen(data12[['PIB_Mex', 'CP']], 0, 4)
johansen1.trace_stat
johansen1.trace_stat_crit_vals


