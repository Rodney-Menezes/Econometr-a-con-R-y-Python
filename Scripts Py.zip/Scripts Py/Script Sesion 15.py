#===========================================
#===========================================
# Curso: Econometría aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 15. Modelos LOGIT y PROBIT
#-------------------------------------------
#-------------------------------------------


#librerias
import numpy as np #para Análisis numérico
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos
import statsmodels.api as sm  #para Construcción de los modelos y realización de las estimaciones
import statsmodels

# Cargar base datos
ruta = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_15\\LogitProbit.csv"
data15 = pd.read_csv(ruta)
data15.columns

#Resumenes estadisticos
data15.describe()
data15['sexo'].describe()

#Estimar los modelos Logit y Probit:
#------------------------------------

#Probit:
modelProbit = statsmodels.discrete.discrete_model.Probit(data15['sexo'], data15[['ing_x_hrs', 'ingocup', 'escolaridad', 'exper']])
Probit1 = modelProbit.fit()
Probit1.summary()

#Logit:
modelLogit = statsmodels.discrete.discrete_model.Logit(data15['sexo'], data15[['ing_x_hrs', 'ingocup', 'escolaridad', 'exper']])
Logit1 = modelLogit.fit()
Logit1.summary()

#Efectos marginales:
#--------------------

#Logit
Logit1.get_margeff().summary()

#Probit
Probit1.get_margeff().summary()

