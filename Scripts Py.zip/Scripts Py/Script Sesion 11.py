#===========================================
#===========================================
# Curso: Econometría aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 11. Analisis de Integracion
#-------------------------------------------
#-------------------------------------------


#Instalar librerias
#pip install pmdarima

#Cargar librerias
import numpy as np #para Análisis numérico
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos
import statsmodels.api as sm  #para Construcción de los modelos y realización de las estimaciones y tests
from statsmodels.formula.api import ols
from scipy import stats
from statsmodels.tsa.arima.model import ARIMA
from pmdarima.arima import auto_arima

# Cargar base de  y dar formato de series de tiempo
ruta = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_10\\interes.csv"
data10 = pd.read_csv(ruta, index_col=0)

#mostramos las primeras lineas
data10.head(5)
#mostramos las ultimas lineas
data10.tail(4)

#damos formato de series de tiempo
data10['year']  = pd.date_range(start='1980Q1', end='1999Q2', freq='BQ')
#data10['year']  = pd.date_range(start='1980/1', end='1999/2', freq='BQ') <- otra forma

data10.columns
data10.index

#Notas sobre las frecuencias temporales
#.......................................
Data = pd.date_range(start='1960', end='1980', freq='Y')

#Hora: freq='H'
#2 Horas: freq='2H'
#Dia: freq='D'
#2Dias: freq='2D'
# Valores al cierre de cada mes: freq='M'
#Valores al cierre de cada mes (días laborales) = freq='BM'
#valores al cierre de cada trimestre: freq='BQ'
#Ano: freq='Y'

#ejemplo de dias lavorables de la Bolsa de valores:
Data = pd.date_range(start='1980/01/01', end='1980/01/30', freq='5D')
     

#Resumenes estadisticos
data10.describe()

# Visualizamos rápidamente las caraterísticas de entrada
data10.hist()
plt.show()

#eliminamos los valores perdidos
data10 = data10.dropna()


#Analisis grafico de las variables
#----------------------------------

#Grafica de DEFPART
data10['DEFPART'].plot()

#Grafica de IEPPART
data10['IEPPART'].plot()

#Grafica de SALDOP
data10['SALDOP'].plot()

#Grafica de SALDOPP
data10['SALDOPP'].plot()

#Grafica de TINTER
data10['TINTER'].plot()


#Estimacion del modelo MCO 
#-------------------------
model = ols('TINTER ~ SALDOPP + DEFPART + IEPPART' , data=data10).fit()
#mostramos el resultados del modelo
model.summary()


#Modelo ARMA
#------------

#grafica de la FAS Y FAP
fig = plt.figure(figsize=(12,8))
ax1 = fig.add_subplot(211)
fig = sm.graphics.tsa.plot_acf(data10['TINTER'].values.squeeze(), lags=40, ax=ax1)
ax2 = fig.add_subplot(212)
fig = sm.graphics.tsa.plot_pacf(data10['TINTER'], lags=40, ax=ax2)

#Auto ARIMA
auto_arima(data10['TINTER'])

#calculando los posibles ARMA:
arma_mod1= ARIMA(data10['TINTER'], order=(2, 0, 5)).fit()
print(arma_mod1.params)
arma_mod1.summary()

#test de Durbin watson
sm.stats.durbin_watson(arma_mod1.resid.values)
 
#Realizando prueba de Breusch-Godfrey
sm.stats.diagnostic.acorr_breusch_godfrey(arma_mod1)

#Prueba ADF 
DFx = sm.tsa.stattools.adfuller(data10['TINTER'], maxlag = None, regression = 'c' #{"c", "ct", "ctt", "nc"}
                                   , autolag = 'AIC' #{"AIC", "BIC", "t-stat", None} 
                                   , store = False , regresults = False )


