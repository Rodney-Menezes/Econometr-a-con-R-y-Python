#===========================================
#===========================================
# Curso: Econometría aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 6. Error de especificación 
#-------------------------------------------
#-------------------------------------------


#librerias
import numpy as np #para Análisis numérico
import pandas as pd #para manejo de datos
import matplotlib.pyplot as plt #Para graficos
import statsmodels.api as sm  #para Construcción de los modelos y realización de las estimaciones

# Cargar base de datos
ruta = "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_6\\Gasolina.csv"
colnames=['Año','G','Pobl','Pg','Y','Pan','Pau','Ptp','Pd','Pnd','Ps'] 
data6 = pd.read_csv(ruta, names=colnames, skiprows=1)

data6.columns

# Creandon nuevas variables
x1 = np.log(data6['G']/data6['Pobl'])
x2 = np.log(data6['Y'])
x3 = np.log(data6['Pg'])
x4 = np.log(data6['Pan'])
# Uniendo las variables a la base de datos
data6 = data6.assign(LogGPob = x1.values)
data6 = data6.assign(LogY = x2.values)
data6 = data6.assign(LogPg = x3.values)
data6 = data6.assign(LogPan = x4.values)

# Ahora veamos algunas estadísticas de nuestros datos
data6.describe() #todo el dataset
data6['Y'].describe() #solo una variable variables
data6[['Y', 'Pg']].describe() #solo algunas variables

# Visualizamos rápidamente las caraterísticas de entrada
data6.hist()
plt.show()

#Estimar los coeficientes del modelo de regresión múltiple: 

#eliminamos los valores perdidos
data6 = data6.dropna()

#separamos la varibale dependiente de las independientes
Y = data6["LogGPob"]
X = data6[["LogY", "LogPg", "LogPan"]]

# Creamos el objeto de Regresión Linear
MiModelo1 = sm.OLS(Y, sm.add_constant(X))

#guardamos las estimaciones del modelo
Resultados = MiModelo1.fit()

#mostramos los resultados del modelo
Resultados.summary()
    
# Prueba RESET
sm.stats.diagnostic.linear_reset(Resultados)

sm.stats.diagnostic.linear_reset(Resultados , power = 3 , test_type = 'fitted' , use_f = False , cov_type = 'nonrobust')

