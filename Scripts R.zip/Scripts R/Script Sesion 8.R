#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 8. multicolinealidad
#-------------------------------------------
#-------------------------------------------


#Instalamos paquetes:
install.packages("tidyverse")
library(tidyverse)
library(readxl)
library(car)

#Importamos datos
file.choose()
base8 <- read_excel("C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_8\\consumo_fun.xlsx")
summary(base8)

#Creacion de variables
baseEjemplo<- mutate(base8,
       lRQR = log(RQR),
       ltceer = ltcr / lcpr * 60
)

#Estimamos el modelo
regmodel1<-lm(formula = lcpr ~ lrqr + ltcr + lydr, data = base8)
summary(regmodel1)

#Coeficientes de correlaci�n
cor(base8[,c("lydr","lrqr","ltcr")], use="complete")

#Factor de inflaci�n-varianza (VIF)
vif(regmodel1)

#Regresiones auxiliares: La regla de Klein.
regmodel2<-lm(formula = lydr ~ lrqr + ltcr, data = base8)
summary(regmodel2)

# Regresiones auxiliares: El efecto de Theil
regmodel3<-lm(formula = lcpr ~ lrqr + ltcr, data = base8)
summary(regmodel3)
regmodel4<-lm(formula = lcpr ~ lrqr + lydr, data = base8)
summary(regmodel4)
regmodel5<-lm(formula = lcpr ~ ltcr + lydr, data = base8)
summary(regmodel5)

#Ejemplo de solucion a la multicolinealidad

PC <- princomp(~lrqr+lydr, cor=TRUE, data=base8)
unclass(loadings(PC))  # cargando componentes
PC$sd^2  # componentes de la varianza
summary(PC) # proporciones de varianza
attach(PC)

base8.1 <- mutate(base8, PC1 = ltcr + lydr) # creamos una nueva variable (con combinacion lineal) en una base de datos

reg1 <- lm(formula = lcpr ~ ltcr + PC1, data = base8.1)
summary(reg1)
