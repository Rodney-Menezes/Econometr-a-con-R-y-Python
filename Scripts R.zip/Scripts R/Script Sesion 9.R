#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 9. Hetrerocedasticidad
#-------------------------------------------
#-------------------------------------------


#librerias
install.packages("car")
library(readxl)
library(lmtest) 
library(car)


file.choose()
ruta_excel <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_9\\NumCajas.xlsx"

distribuci�n <- read_excel(ruta_excel)

#para estimar los coeficientes del modelo de regresi�n lineal m�ltiple 
lm(Tiempo ~ Cajas + Distancia, data=distribuci�n)

# Se le asignara un nombre a los resultados de los coeficientes 
modelo <- lm(Tiempo ~ Cajas + Distancia, data=distribuci�n)

#para saber que se guard� con ese nombre vamos a poner 
modelo

#para obtener las caracter�sticas del modelo se utiliza el siguiente comando
summary(modelo)

#para obtener la matriz de covarianzas se aplica el siguiente comando
vcov(modelo)

#para desarrollar, mejor el an�lisis utilizar la tabla ANOVA, aplicaremos el siguiente comando
anova(modelo)

# Para obtener el vector de residuos utilizamos el siguiente comando, 
#nos sirven para revisar las propiedades de los errores
residuales<-modelo$residuals

#Tenemos que revisar los supuestos de normalidad de los residuos, a trav�s de:
rstint<-rstandard(modelo)
summary(rstint)

#para poder observar los gr�ficos 
hist(rstint)
boxplot(rstint)
qqnorm(rstint)

#para detectar la heterocedasticidad dentro del modelo aplicamos la prueba Breusch-Pagan
bptest(modelo)

#vamos a aplicar una prueba de nombre White, esto con el fin de devolver las matrices de covarianza corregidas para hacer las inferencias
hccm(modelo)

#para obtener los resultados de las pruebas que hicimos aplicamos el siguiente comando
coeftest(modelo)
