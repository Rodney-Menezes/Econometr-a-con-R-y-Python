#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 10. Autocorrelaci�n Serial y series de tiempo
#--------------------------------------------------------
#--------------------------------------------------------


# Primero debemos instalar los siguientes paquetes
#install.packages("tidyverse")
library(tidyverse)
library(forecast)
#install.packages("lmtest")
library(lmtest)
#install.packages("stats")
library(stats)

# La ruta de nuestro archivo, en este caso debe ser guardado en formato csv.
file.choose()
basecorre <- read.csv("C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_10\\interes.csv")
attach(basecorre)

# Definiendo las series como series de tiempo
mst<-ts(basecorre, start=c(1980,1), end=c(1999,1), frequency=4)

# En caso de que la base sea anual 
mst<-ts(basecorre, start=c(1980), end=c(1999))

# Generalizando para otro tipo de frecuencia  
#ts (nombre-de-la-base, start=c(year,period), end=c(year, pediod), frequency=) 
#donde frequency es el numero de observaciones por unidad en el tiempo y pueden ser 1=anual, 
#4=trimestral,12=mensual).

#Analizar las variables antes de la modelaci�n 
summary (basecorre)

# Estimaci�n del modelo por MCO
mcor<-lm(TINTER~SALDOPP+DEFPART+IEPPART)

#Realizando Correlogramas
acf (TINTER)
pacf (TINTER) 

#Auto ARIMA
auto.arima(TINTER)

#Modelo ARIMA
Arima1 <- Arima(TINTER, order=c(1,0,1),method="ML")
coeftest(Arima1)
resid <- Arima1['residuals']


#Analizamos la Informaci�n
summary (mcor)
summary (Arima1)

# Revisar la autocorrelaci�n Gr�ficamente 
plot(mst)


# Realizando prueba Durbin-Watson
dwtest(mcor)

