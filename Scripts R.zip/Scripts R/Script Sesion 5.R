#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 5. El modelo de regresi�n multiple 
#-------------------------------------------
#-------------------------------------------

#cargando paquetes

#install.packages('readxl')
library(readxl)

file.choose()
ruta_excel <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_5\\Sesion5_datos.xls"

base5 <- read_excel(ruta_excel, sheet = NULL, range = 'A2:J81') 

objects(base5) # Ver las variables

#Cambiar nombre de variables
base5<- rename(base5, inflacion = `Indicadores econ�micos de coyuntura > Precios e inflaci�n > �ndice nacional de precios al consumidor > Mensual > �ndice �ndice general a/  f2/ (Base segunda quincena de diciembre 2010 = 100)`) 
base5<- rename(base5, IsecManufc =`Indicadores econ�micos de coyuntura > Indicadores del sector manufacturero (EMIM) > Series originales > �ndice de las remuneraciones medias reales por persona ocupada > �ndice > Total Total de la industria manufacturera p1 / f1/ (�ndice base 2008 = 100)`) 
base5<- rename(base5, Indice = `�ndice(�ndice base 2003 = 100)`) 

#Resumen de estadisticas de la variable
summary(base5)

#Visualizacion rapida de datos
hist(base5$inflacion)
hist(base5$Indice)
hist(base5$INPC)
hist(base5$LINGR)

#Comando para estimar los coeficientes del modelo de regresi�n m�ltiple: 
#conformado por: lm("nombre de la variable explicada" ~ variable explicatoria1 + variable 
#explicatoria2 + variable explicatoria3, data ="nombre de la base de datos)

lm(VENTAS ~ INPC + REMPO + LPR + LVENTA + LINGR, data = base5)


#Comando para guardar los datos del modelo
# "nombre asignado" <- lm("nombre de la variable explicada" ~ variable explicatoria1 + variable explicatoria2 + variable explicatoria3)

resultado <- lm(VENTAS ~ INPC + REMPO + LPR + LVENTA + LINGR, data = base5)

#Mostrar el resumen de la estimacion
summary(resultado)
