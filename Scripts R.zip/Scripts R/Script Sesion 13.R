#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 13. El modelo VAR 
#-------------------------------------------
#-------------------------------------------



# Crear el objeto mex_var en base a los datos en el archivo base_var_inflacion.csv
file.choose()
ruta <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_13\\base_var_inflacion.csv"
INF_var<-read.csv(ruta, header=T)
attach(INF_var)

# Una vez creado el objeto de trabajo, se procede a dar formato de series de tiempo a la base de datos.
#Para la oferta monetaria
tm2=ts(INF_var[,1], start=2000, freq=12)

#Para el �ndice de precios 
tp=ts(INF_var[,2], start=2000, freq=12) 

#A estas nuevas variables se les aplica logaritmo:
#Para la oferta monetaria
ltm2<-log(tm2)
#Para el �ndice de precios.
ltp<-log(tp)

#Para graficar las series
ts.plot(ltp, ltm2, col=c("blue", "red"))

#Para instalar el paquete "vars" para realizar las pruebas de ra�ces unitarias.
install.packages("vars")
library("vars") 

#Para aplicar la prueba ADF sin constante ni tendencia.
adf1_ltp<-summary(ur.df(ltp, lags=1))
adf1_ltp 

#Para aplicar la prueba ADF con constante o con deriva.
adf2_ltp<-summary(ur.df(ltp, type="drift", lags=12))
adf2_ltp

#Para aplicar la prueba ADF con tendencia.
adf3_ltp<-summary(ur.df(ltp, type="trend", lags=1))
adf3_ltp

# Para que las variables sean estacionarias se procede generar las segundas diferencias de las variables.
# Para generar la primera diferencia del logaritmo del �ndice de precios
dltp<-diff(ltp)

# Para generar la segunda diferencia del logaritmo del �ndice de precios
d2ltp<-diff(dltp)

# Para generar la primera diferencia del logaritmo de la oferta monetaria
dltm2<-diff(ltm2)

# Para generar la segunda diferencia del logaritmo de la oferta monetaria
d2ltm2<-diff(dltm2)

# Para graficar las variables se utiliza el siguiente comando. 
ts.plot(d2ltp, d2ltm2, col=c("blue", "red"))

#Para analizar la causalidad de granger en las variables se utilizan los siguientes comandos 
#La causalidad de la oferta monetaria hacia los precios.
grangertest(d2ltp~d2ltm2, order=1)

#La causalidad de los precios hacia la oferta monetaria. 
grangertest(d2ltm2~d2ltp, order=1)

#Para la creaci�n del var se procede a crear un nuevo objeto con las variables 
#estacionarias y transformadas en series de tiempo. 
mex_var2<-data.frame(d2ltm2,d2ltp)

#Para la identificaci�n del VAR. 
VARselect(mex_var2, lag.max=12)

#Para la estimaci�n del VAR.
var1<-VAR(mex_var2,p=11)
var1

#Para saber si el VAR satisface las condiciones de estabilidad se utiliza el siguiente comando.
summary(var1) 

#Para obtener el grafico de la variable observado vs la estimada del Modelo var se utiliza la siguiente funci�n
plot(var1)

#Para realizar las pruebas de especificaci�n del VAR, se utilizan los siguientes comandos.

#Para realizar la prueba de autocorrelaci�n se usa el siguiente comando.
seriala<-serial.test(var1, lags.pt=11, type="PT.asymptotic")
seriala$serial  

#Para la prueba de normalidad.
normalidad<-normality.test(var1)
normalidad$jb.mul 

#Para analizar el impulso respuesta de la variable estudiada y observar su trayectoria.
#Para el impulso respuesta del �ndice de precios.
var1_irfltp<-irf(var1, response="d2ltp", n.ahead=8, boot=TRUE)
var1_irfltp 

#Para graficar el impulso respuesta
plot(var1_irfltp)

#Para el impulso respuesta de la oferta monetaria.
var1_irfltm2<-irf(var1, response="d2ltm2", n.ahead=5, boot=TRUE)
var1_irfltm2

#Para graficar el impulso respuesta
plot(var1_irfltm2) 

#Para el an�lisis de la descomposici�n de varianza de las variables, se usan los siguientes comandos.

#Para el �ndice de precios.
var1_fevd_d2ltp<-fevd(var1, n.ahead=50)$d2ltp
var1_fevd_d2ltp 

#Para la oferta monetaria. 
var1_fevd_d2ltm2<-fevd(var1, n.ahead=50)$d2ltm2
var1_fevd_d2ltm2
