#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 7. Normalidad
#-------------------------------------------
#-------------------------------------------

# Instalamos paquetes:
install.packages("tseries")
library(tseries) 

# cargamos los datos:
file.choose()
setwd("C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_7") # establecemos directorio.
Elast<-read.table("Elast.txt", header=TRUE, sep=",")
attach(Elast)

Gasolina<-read.table("Gasolina.txt",header=TRUE,sep=",")
attach(Gasolina)


#Dandole formato de series de tiempo: Nota: para este caso es opcional
elast<-ts(Elast, start=c(1960), end=c(2004))
gass<-ts(Gasolina, start=c(1993,1), end=c(2013,4), frequency=4)
summary(elast)
summary(gass)

#Nota: Gasolina o gass, las 2 bases de datos son equivalentes y lo mismo para Elast
summary(gass)
summary(Gasolina)

summary(elast)
summary(Elast)

# Prueba Jarque-Bera
gass<-rnorm(100)
jarque.bera.test(gass)

elast<-rnorm(100)
jarque.bera.test(elast)

# En la practica la prueba jarque-Bera se debe hacer a los residuales
model1g<-lm(log(G/Pobl)~log(Y)+log(Pg)+log(Pan)) 
jarque.bera.test(residuals(model1g))

model2g<-lm(log(G/Pobl)~log(Y)+log(Pg)+log(Pan)+log(Pd)) 
jarque.bera.test(residuals(model2g))

model1e<-lm(log(DRel)~log(PRel)+log(PIB)) 
jarque.bera.test(residuals(model1e))

#Graficas:
#model1g
hist(residuals(model1g))
#model2g
hist(residuals(model2g))
#model1e
hist(residuals(model1e))



