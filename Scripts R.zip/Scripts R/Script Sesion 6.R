#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 6. Error de especificaci�n 
#-------------------------------------------
#-------------------------------------------


# La prueba RESET en R, requiere del paquete llamado lmtest.

install.packages("lmtest") #Instalar el paquete  
library(lmtest) #llamar paquete

# Para cargar base de datos "Gasolina.txt"se escribir�:
#"nombre de la base de datos" <- read.csv("nombre.terminacion")

#Ejemplo: 
file.choose()
ruta <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_6\\Gasolina.txt"
Gasolina <- read.csv(ruta)
# Para ver la base de datos se colocara el comando View (nombre de la base de datos)
View(Gasolina)

# attach("nombre de la base de datos) carga en memoria las variables del data frame
attach(Gasolina) 

# Otro comando para importar los datos desde Excel, yo prefiero usar el readxl 
#"nombre del archivo"<-read.delim("ruta de acceso",sep=",",header=T,stringsAsFactors=F)

# El comando para realizar un modelo de regresi�n 
#cons<-lm("nombre de la variable explicada" ~ variable explicatoria1 + variable explicatoria2 + variable explicatoria3)
#Ejemplo: 
cons<-lm(log(G/Pobl)~log(Y)+log(Pg)+log(Pan)) 

# Una vez realizado el modelo el siguiente paso es aplicar la prueba RESET 
#en donde el argumento "" es el nombre del objeto donde se guarda el resultado de la estimaci�n
resettest(cons)

# Para incorporar de la segunda a la cuarta potencia del ajuste se escribir�
resettest(cons,power=2:4)

# Para incorporar solo solo la segunda potencia
resettest(cons,power=2:2)
          
