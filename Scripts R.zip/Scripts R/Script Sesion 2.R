#==================================================
#==================================================
# Curso: Econometr�a aplicada utilizando R y Python
#==================================================
#==================================================
#Instructor: Jose Rodney Menezes De la Cruz
#==================================================
# Sesion 2.  Introducci�n a R
#------------------------------------------------
#------------------------------------------------


###1) Comandos basicos:
#-----------------------

#Para generar un objeto n�mero y que contiene el resultado de multiplicar 2 por 5:
a<- 2
b<-5
y<-a*b

#Tambi�n se podr�a utilizar R como si fuera una calculadora y escribir directamente
2*5

#Podemos listar los objetos creados
objects()
ls()

#Para saber qu� hace objects se escribe
help(objects)

??(objects)

#para eliminar a y b
rm(a,b)

#Para generar un objeto que sea un vector columna podemos usar la opci�n c, 
x <- c(5,10,8,7,9)
#tambi�n puede hacerse con la funci�n assignment:
assign('x', c(5,10,8,7,9))


#Tambi�n podr�amos generar vectores columna con secuencias de n�meros, por ejemplo si generamos una secuencia del 1 al 10:
y<- c(1:10)
y

#A los elementos de un vector se les pueden asignar nombres:
names(x)<-c("cinco","diez","ocho","siete","nueve")
x

#Las gr�ficas se obtienen usando plot, por ejemplo para realizar una gr�fica de los valores del vector y escribimos:
plot(y)



###2) Estadisticas basicas y Regresion lineal simple:
#----------------------------------------------------

#Para generar dos vectores se puede escribir
y<-c(1,2,3,-1,0,-1,2,1,2)
x<-c(0,1,2,-2,1,-2,0,-1,1)

#Tambi�n es posible calcular la media, varianza, m�ximo, m�nimo o la longitud de un vector:
mean(x)
var(x)
max(x)
min(x)     
length(x)

#Para correr esa regresi�n se utiliza la funci�n lineal model o lm:
lm(y~x)

#Los resultados detallados de la regresi�n se pueden obtener con summary()
summary(lm(y~x))



###3) Ruta de trabajo y importacion de archivos ".txt":
#------------------------------------------------------

#Para verificar cu�l es el directorio actual
getwd()

#Para buscar una ruta (no olvidar borrar el nombre del archivo en la ruta dada)
file.choose()

#Si el directorio que aparece no es el que debe utilizar, puede cambiar de directorio con:
setwd("D:\\Cursos\\Econometria con R\\Bases de Datos\\BaseDatos total")

#Para que sus datos puedan ser cargados en R debe usar el comando para leer tablas (read.table) 
#e indicar que la primer l�nea de su cuadro de datos contiene los nombres de las variables (header=TRUE) 
#y que las columnas est�n separadas por tabulaciones (sep=)
datos<-read.table("PWT_2000.txt",header=TRUE,sep="")

#para indicar que las variables est�n en las columnas se debe usar la siguiente instrucci�n:
attach(datos)

#Al pedir un listado a R aparecer� cada una de las variables en la lista:
ls(datos)



###4) Guardar resultados de la regresion:
#----------------------------------------

#Para guardar el resultado en un objeto con nombre PWT:
PWT<-lm(PIBPCL ~ K)
PWT

#Los resultados de la regresi�n
summary(PWT)



###5) Graficas:
#--------------

#Para obtener un diagrama de dispersi�n del objeto
plot(PWT)

#Para a�adir una recta de regresi�n al diagrama de dispersi�n 
abline(PWT)

#Con la siguiente instrucci�n generaremos el histograma para los datos del PIB per c�pita de los pa�ses:
hist(PIBPCL)

#Para a�adirle funciones de densidad kernel:
hist(PIBPCL,freq=FALSE)
lines(density(PIBPCL))

#Para obtener una gr�fica de cajas que  muestre los umbrales para
#los cuartiles inferior y superior, adem�s de la mediana:
boxplot(PIBPCL) 
 