#==================================================
#==================================================
# Curso: Econometr�a aplicada utilizando R y Python
#==================================================
#==================================================
#Instructor: Jose Rodney Menezes De la Cruz
#==================================================
# Sesion 12. Cointegracion
#------------------------------------------------
#------------------------------------------------

#### Ejemplo 1. Metodolog�a de Engle-Granger aplicada a la funci�n Consumo 
#---------------------------------------------------------------------------------------

#Activar las librer�a urca y car 
library(urca) 
library(car) 

#Cambiar el directorio de trabajo 
file.choose()
ruta <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_12\\Consumo.csv"

Consumo <- read.csv(ruta, header = T)

#resumen de estad�stico
summary(Consumo)

# Se asignan las variables de serie de tiempo al objeto PIB_MEX y aplicar primera y segunda diferencia 
lpib_mex <- log(Consumo$PIB_Mex) 
lcp_mex <- log(Consumo$CP) 
dlpib_mex <- diff(lpib_mex) 
dlcp_mex <- diff(lcp_mex) 

# Se asigna la variable  periodo que ordena en el tiempo  
periodo <- Consumo$Periodo 

# Para graficar las variables de los logaritmos del PIB_Mex  y el Consumo_Mex en el tiempo 
plot(periodo, lpib_mex, main="Consumo y PIB de Mexico",xlim = c(15, 17), ylim=c(15, 17)) 
lines(lpib_mex, col="black") 
lines(lcp_mex, col="red") 

# Para construir un gr�fica con las primera diferencia del Consumo y del PIB 
plot(dlpib_mex, main="Diferencias en logaritmo del consumo y del PIB de Mexico") 
lines(dlpib_mex, col="black") 
lines(dlcp_mex, col="red") 

#Para seguir con la metodolog�a de Engle-Granger, en primer lugar se estima la funci�n
#consumo con elasticidades constantes

# Funci�n consumo para probar cointegraci�n tipo Engle y  Granger
mod_1 <- lm(lcp_mex ~ lpib_mex)
summary(mod_1)

#Para generar un objeto con los residuales y graficarlos, se utilizan los siguientes
#comandos   

# Generar los residuales de la ecuaci�n 
res_1 <- residuals.lm(mod_1) 
summary(res_1)

# Grafica de los errores 
residualPlot(mod_1) 

#En segundo lugar, a los residuales de la funci�n consumo se le aplica las pruebas de ra�z unitaria. 

# Prueba de ADF para cointegracion tipo Granger 
lc.df <- ur.df(y=res_1, type='trend',lags=4, selectlags=c("AIC")) 
summary(lc.df) 

# La segunda prueba ADF se aplica solamente con constante 
lc.df <- ur.df(y=res_1, type='drift',lags=4, selectlags=c("AIC")) 
summary(lc.df) 

# Por �ltimo se aplica la prueba ADF sin tendencia y constente 
lc.df <- ur.df(y=res_1, type='none',lags=4, selectlags=c("AIC")) 
summary(lc.df) 



####Ejemplo 2. An�lisis de cointegraci�n de Phillips y Ouliaris (PO) para funci�n Consumo 
#-----------------------------------------------------------------------------------------

#Para este ejemplo, se recomienda que tenga activadas las librer�as, el cambio de directorio, se asignen las variables previo a la aplicaci�n de la prueba de cointegraci�n de PO. 

#Cambiar el directorio de trabajo 
file.choose()
setwd("") 

# Lectura de la base de datos 
load("Consumo.RData") 
summary(Consumo) 

# Se asigna la variable de serie de tiempo al objeto PIB_MEX y  aplicar primera y segunda diferencia 
lpib_mex <- log(Consumo$pib_mex) 
lcp_mex <- log(Consumo$cp_mex) 

# Prueba de Phillips y Ouliaris para cointegracion  

#Para aplicar la prueba PO, primero utilizamos el comando cbind que se usa para integrar variables en un solo objeto 
ecb.consumo <- cbind(lcp_mex, lpib_mex) 

# Entonces se aplica la prueba PO del tipo Pz 
Lc.po <- ca.po(ecb.consumo, type="Pz") 
summary(Lc.po)
#Los resultados muestran que el estad�stico calculado (10.99) es menor que el valor critico
#al 10 porciento (33.92) y todos los niveles de significancia, con lo que se concluye que se
#acepta la hip�tesis nula de no cointegraci�n.

# Entonces se aplica la prueba PO del tipo Pu 
Lc.po <- ca.po(ecb.consumo, type="Pu") 
summary(Lc.po)
#La conclusi�n con la prueba Pz se confirma con el estad�stico Pu; el estad�stico calculado
#(9.39) es menor que el valor critico al 10 porciento (20.39) y todos los niveles de
#significancia, con lo que se concluye que se acepta la hip�tesis nula de no cointegraci�n


#Ejemplo 4. An�lisis de cointegraci�n de Johansen-Joselius  
#---------------------------------------------------------------------------------------

#Activar las librer�a urca y car 
library(urca) 
library(car) 

#Cambiar el directorio de trabajo 
file.choose()
setwd("") 

# Lectura de la base de datos 
load("Consumo.RData") 

# Se asigna la variable de serie de tiempo al objeto PIB_MEX y  aplican primeras diferencias 
lpib_mex <- log(Consumo$pib_mex) 
lcp_mex <- log(Consumo$cp_mex) 

# Para aplicar el procedimiento de Johansen, primero se combinan las variables en un solo objeto 
ecb.consumo <- cbind(lcp_mex,lpib_mex) 

#En primer lugar se aplica la prueba de la traza de cointegraci�n sin tendencia y constante  

# Prueba  Johasen de cointegracion de la traza  
summary(ca.jo(ecb.consumo, type="trace",ecdet="none",spec=c("longrun"), K=4)) 

#Los resultados muestran que para la primera hip�tesis r =0 y alternativa r=1, se acepta la
#hip�tesis alternativa de cointegraci�n: el estad�stico es mayor al valor critico del 10
#porciento,  18.04 > 15.56. Para la segunda hip�tesis r<=1 y alternativa r=2, se acepta la
#hip�tesis nula de un solo vector de cointegraci�n. Por lo que se puede concluir que existe
#un vector de cointegraci�n y se representa por [1 -1.28]. 

# Prueba de Johansen de la traza con constante  
summary(ca.jo(ecb.consumo, type="trace",ecdet="const",spec=c("longrun"), K=4)) 

#Los resultados muestran que para la primera hip�tesis r =0 y alternativa r=1, se acepta la
#hip�tesis alternativa de cointegraci�n: el estad�stico es mayor al valor critico del 10
#porciento,  31.01 > 17.85. Para la segunda hip�tesis r<=1 y alternativa r=2, se acepta la
#hip�tesis alternativa nula de dos vector de cointegraci�n. Por lo que se pueden identificar 
#los vectores de cointegraci�n [1 -1.25 4.55] y [1 -1.41 7.19]. 

# Prueba de Johansen de la traza con tendencia   
summary(ca.jo(ecb.consumo, type="trace",ecdet="trend",spec=c("longrun"), K=4)) 

#Al igual que en el caso de la opci�n sin tendencia y constante,  se acepta la hip�tesis de
#cointegraci�n con solo vector. El vector de cointegraci�n es  [1  -2.61  0.008]


