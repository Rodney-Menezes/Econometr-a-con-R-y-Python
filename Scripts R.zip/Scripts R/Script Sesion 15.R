#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 15. Modelos LOGIT y PROBIT
#-------------------------------------------
#-------------------------------------------


#librerias:
install.packages('mfx')
install.packages('betareg')

library(mfx, betareg) #efectos marginales

#Ejemplo. Modelos probabilisticos logit y probit  
#------------------------------------------------

#Los modelos probabil�sticos que se presentan se elaboraron para predecir la probabilidad de
#obtener ingresos por hora por arriba de la mediana (p), de acuerdo a los a�os de escolaridad, la
#experiencia y el sexo.  ln(????????) = ???? + ????1 + ????2 +????3 + ????4 

#Datos: Los indicadores se construyeron con la Encuesta Nacional de Ocupaci�n y Empleo (ENOE) 2015 del INEGI. 

# Para llevar estimar los modelos probabil�sticos se utilizan las herramientas de la librer�a de stats. 
library(stats) 

#Cargamos los datos 
file.choose()
ruta <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_15\\LogitProbit.csv"

# Lectura de Base de Datos previamente salvada en formato de RData 
Data15 <- read.csv(ruta)

# Se adjunta la base se de datos para hacerla accesible 
attach(Data15)

#Nota de la base de datos:La base de datos  contiene las siguientes variables que se utilizaran para la estimaci�n de 
#losmodelos probabil�sticos: el ingreso por hora (ing_x_hrs) con la cual se construye la 
#variable dummydonde toma el valor de 1 si esta arriba de la media y cero en otro caso; 
#los a�os de escolaridadcon seis a�os de primaria, tres de secundaria, tres de bachiller, 
#cinco de licenciatura, dos demaestr�a y cinco de doctorado; la experiencia igual a la edad 
#menos escolaridad y seis a�os; y finalmente la variable sexo con uno para hombres y cero mujeres.    

# Estad�sticos b�sicos de variables 
summary (Data15) 

# Para comprobar que se genero una variable dummy 
summary (Data15$sexo) 

## Se estiman los modelos logit y probit 

# Modelo logit 
mod_logit <- glm(sexo~escolaridad+exper, data=Data15, family = binomial(link="logit")) 
summary(mod_logit)

# Modelo probit 
mod_probit <- glm(sexo~escolaridad+exper, data=Data15, family = binomial(link="probit")) 
summary(mod_probit)

#Efectos marginales:
#....................
#Logit
logitMfx<-logitmfx(sexo~escolaridad+exper, data=Data15)
logitMfx
#Probit
probitMfx<-probitmfx(sexo~escolaridad+exper, data=Data15)
probitMfx

