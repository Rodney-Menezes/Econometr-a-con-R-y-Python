#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 3. AE y limpieza de datos 
#-------------------------------------------
#-------------------------------------------


# librerias
install.packages("tidyverse")
library(tidyverse)

#cargar datos
file.choose()
rutaA <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\autos.csv"
rutaB <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\diamantes.csv"
rutaC <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\vuelos.csv"
rutaD <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\tabla1.csv"
rutaE <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\tabla2.csv"
rutaF <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\tabla3.csv"
rutaG <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\tabla4a.csv"
rutaH <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_3\\tabla4b.csv"  

baseA3 <- read_csv(rutaA, col_names = T)
baseB3 <- read_csv(rutaB, col_names = T)
baseC3 <- read_csv(rutaC, col_names = T)
tabla1 <- read_csv(rutaD, col_names = T)
tabla2 <- read_csv(rutaE, col_names = T)
tabla3 <- read_csv(rutaF, col_names = T)
tabla4a <- read_csv(rutaG, col_names = T)
tabla4b <- read_csv(rutaH, col_names = T)



#visualizacion de datos
#----------------------
baseA3$cilindrada

#Creando un gr�fico con ggplot
#-----------------------------

#Plantilla:
#ggplot(data = <DATOS>) +
#  <GEOM_FUNCI�N>(mapping = aes(<MAPEOS>))

#Ejemplos:
ggplot(baseA3) +
  geom_point(mapping = aes(x = cilindrada, y = autopista))

ggplot(baseA3) +
  geom_point(mapping = aes(x = cilindrada, y = autopista), color = "blue")

  ggplot(baseA3) +
    geom_point(mapping = aes(x = cilindrada, y = autopista, color = clase))

ggplot(baseA3) +
  geom_point(mapping = aes(x = cilindrada, y = autopista, size = clase))

ggplot(baseA3) +
  geom_point(mapping = aes(x = cilindrada, y = autopista, alpha = clase))
#alpha controla la transparencia de los puntos

ggplot(baseA3) +
  geom_point(mapping = aes(x = cilindrada, y = autopista, shape = clase))
#shape controla la forma de los puntos

ggplot(baseA3) +
  geom_point(mapping = aes(x = cilindrada, y = autopista)) +
  facet_wrap(~ clase, nrow = 2)
#para dividir en facetas de una variable (En este caso "clase")

ggplot(baseA3) +
  geom_point(mapping = aes(x = cilindrada, y = autopista)) +
  facet_grid(traccion ~ cilindros)
#para dividir en facetas de 2 variables

#Para mostrar m�ltiples geoms en el mismo gr�fico, agrega varias funciones geom
ggplot(data = baseA3) +
  geom_point(mapping = aes(x = cilindrada, y = autopista)) +
  geom_smooth(mapping = aes(x = cilindrada, y = autopista))

#grafica de barras
#estadistica de frecuencia
ggplot(data = baseB3) +
  geom_bar(mapping = aes(x = corte, y = stat(count), group = 1))

#stat con estadistica de proporciones
ggplot(data = baseB3) +
  geom_bar(mapping = aes(x = corte, y = stat(prop), group = 1))

#con resumen estadistico (min, max, mean/median)
ggplot(data = baseB3) +
  stat_summary(
    mapping = aes(x = corte, y = profundidad),
    fun.min = min,
    fun.max = max,
    fun = median
  )

#para conocer la lista completa de transformaciones estadisticas de ggplot2
?ggplot2


# Filtrar filas
#---------------

#filter() te permite filtrar un subconjunto de observaciones seg�n sus valores. 
#El primer argumento es el nombre del data frame. Los siguientes argumentos son las 
#expresiones que lo filtran.

ene1 <- filter(baseC3, mes == 1, dia == 1)
dic25 <- filter(baseC3, mes == 12, dia == 25)

#mes 11 o 12
filter(baseC3, mes == 11 | mes == 12)

#Si deseas determinar si falta un valor, usa is.na():
is.na(baseC3$distancia)

#borrar las observaciones con n.a
baseC3 %>% drop_na()

#Cambiar nombre de variables
baseC3 <- rename(baseC3, cola_num = codigo_cola) # nuevo nombre cola_num


# A�adir nuevas variables 
#-------------------------

#mutate() siempre agrega nuevas columnas al final de un conjunto de datos

#subconjunto nuevo de datos
vuelos_sml <- select(baseC3,
                     anio:dia,
                     starts_with("atraso"),
                     distancia,
                     tiempo_vuelo
)

#A�adiendo dos variables nuevas
vuelos_sml <- mutate(vuelos_sml,
       ganancia = atraso_salida - atraso_llegada,
       velocidad = distancia / tiempo_vuelo * 60
)

#A�adiendo mas variables
vuelos_sml <- mutate(vuelos_sml,
       ganancia = atraso_salida - atraso_llegada,
       horas = tiempo_vuelo / 60,
       ganacia_por_hora = ganancia / horas
)

#Si solo quieres conservar las nuevas variables, usa transmute():
vuelos_sml <- transmute(baseC3,
          ganancia = atraso_salida - atraso_llegada,
          horas = tiempo_vuelo / 60,
          ganancia_por_hora = ganancia / horas
)

#eliminar variables
vuelos_sml <- vuelos_sml[ ,!colnames(vuelos_sml)=="ganancia"]



#Ordenamiento de datos:
#-----------------------

# Datos ordenados
#-----------------

#El conjunto de datos ordenado, sera� mucho mas facil de trabajar dentro del tidyverse.
#Existen tres reglas interrelacionadas que hacen que un conjunto de datos sea ordenado:
# . Cada variable debe tener su propia columna.
# . Cada observacion debe tener su propia fila.
# . Cada valor debe tener su propia celda.

#Puedes representar los mismos datos subyacentes de multiples formas. El ejemplo a continuacion muestra
#los mismos datos organizados de cuatro maneras distintas. 

tabla1 #solo la "tabla1" esta ordenada
tabla2
tabla3
# Dividido en dos tibbles
tabla4a # casos
tabla4b # poblacion


# Datos alargados
#-----------------

#Un problema comun es cuando en un dataset los nombres de las columnas no representan nombres de 
#variables, sino que representan los valores de una variable. Tomando el caso de la "tabla4a": 
#los nombres de las columnas "1999" y "2000" representan los valores de la variable "a�o", 
#los valores en las columnas "1999" y "2000" representan valores de la variable "casos" y cada fila 
#representa dos observaciones en lugar de una.

#Para ordenar un dataset como este necesitamos pivotar las columnas que no cumplen en un nuevo 
#par de variables.Para ello podemos utilizar la funcion "pivot_longer()" (pivotar a lo largo):
tidy4a <- tabla4a %>%
  pivot_longer(cols = c(`1999`, `2000`), names_to = "anio", values_to = "casos")
#Las columnas a girar quedan seleccionadas siguiendo el estilo de notacion de "dplyr::select()"

#Podemos usar "pivot_longer()" para ordenar "tabla4b" de modo similar. La unica diferencia es 
#la variable almacenada en los valores de las celdas:
tidy4b <- tabla4b %>%
  pivot_longer(cols = c(`1999`, `2000`), names_to = "anio", values_to = "poblacion")

#Para combinar las versiones ordenadas de "tabla4a" y "tabla4b" en un unico tibble, 
#necesitamos usar dplyr::left_join()
tidy4ab <- left_join(tidy4a, tidy4b)


# Datos Anchos
#--------------

#"pivot_wider()" (pivotar a lo ancho) es lo opuesto de "pivot_longer()". Se usa cuando una observacion 
#aparece en multiples filas. Por ejemplo, considera la "tabla2": una observacion es un pais en un a�o,
#pero cada observacion aparece en dos filas.
tidy2 <- tabla2 %>%
  pivot_wider(names_from = tipo, values_from = cuenta)



# Uniones:
# --------

# Tipos de Uniones
#----------------------

x <- tribble( ~key, ~val_x, 
              1, "x1", 
              2, "x2", 
              3, "x3")
y <- tribble( ~key, ~val_y, 
              1, "y1", 
              2, "y2", 
              4, "y3")

# (1). Union interior (inner join): Una union interior une pares de observaciones siempre que
#      sus claves sean iguales:
x %>%
  inner_join(y, by = "key")

# (2). Uniones exteriores: Una union exterior mantiene las observaciones que aparecen en al menos
#      una de las tablas. Existen tres tipos de uniones exteriores:
#       . Una union izquierda (left join): mantiene todas las observaciones en "x".
left_join(x, y, by = "key")
#       . Una union derecha (right join): mantiene todas las observaciones en "y".
right_join(x, y, by = "key")
#       . Una union completa (full join): mantiene todas las observaciones en "x" e "y".
full_join(x, y, by = "key")


# laves duplicadas:
#-------------------

# No siempre hay claves unicas:

# 1. Una tabla tiene claves duplicadas. Esto es util cuando quieres agregar informacion adicional
#    dado que tipicamente existe una relacion uno a muchos.
x <- tribble( ~key, ~val_x,
              1, "x1", 
              2, "x2", 
              2, "x3", 
              1, "x4")
y <- tribble( ~key, ~val_y, 
              1, "y1", 
              2, "y2")

left_join(x, y, by = "key")

# 2. Ambas tablas tienen claves duplicadas. Esto es usualmente un error debido a que en ninguna de 
#    las tablas las claves identifican de manera unica una observacion. Cuando unes claves duplicadas, 
#    se obtienen todas las posibles combinaciones, es decir, el producto cartesiano:
x <- tribble(
  ~key, ~val_x,
  1, "x1",
  2, "x2",
  2, "x3",
  3, "x4")
y <- tribble(
  ~key, ~val_y,
  1, "y1",
  2, "y2",
  2, "y3",
  3, "y4")

left_join(x, y, by = "key")

