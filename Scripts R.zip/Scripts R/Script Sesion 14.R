#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 14. Modelos ARCH
#-------------------------------------------
#-------------------------------------------


install.packages("rugarch")
library(rugarch)

## abrimos el archivo ipc.csv que contiene las observaciones mensuales de los rendimientos del IPC de 2000.02 a 2010.08.##
file.choose()
ipc <- read.table("D:\\Cursos\\Econometria con R\\Bases de Datos\\BaseDatos_Capitulo_1\\ipc.csv", header=TRUE, quote="\"'")

ipc
## visualizamos la variable de rendimientos en un grafico de linea con la siguiente sintaxis ##
plot(ipc, main= "Rendimiento del IPC")

## Examinamos la serie con los correlogramss para identificar el tipo de proceso ARIMA que podria representar a la seria ##
acf.ipc=acf(ipc$IPCREND,main='ACF IPC',lag.max=100,ylim=c(- 0.5,1)) 
pacf.ipc=pacf(ipc$IPCREND,main='PACF IPC',lag.max=100,ylim=c(-0.5,1))

## Estimamos el proceso mas simple con los resultados obtenidos y es un ARMA(2,2)##
arima22=arima(ipc$IPCREND,order=c(2,0,2)) 

## llamamos al objeto ##
arima22

## generamos los residuales del modelo ##
res.arima22=arima22$res

## los graficamos ##
plot(res.arima22,type='l',main='Residuales')

## obtenemos el correlograma d los residuales ##
acf.res=acf(res.arima22,main='ACF Residuales',lag.max=100,ylim=c(- 0.5,1))
pacf.res=pacf(res.arima22,main='PACF Residuales',lag.max=100,ylim=c(-0.5,1))

## examinamos los residuales elevados al cuadrado con el fin de examinar su varianza ##
cuad.res.arima22=res.arima22^2
par(mfcol=c(3,1))
plot(cuad.res.arima22,main='Residuales al cuadrado')

## Los correlogramas de los residuales al cuadrado son evidencia de la heterocedasticidad presente en la varianza, as� que obtenemos los correlogramas ##
acf.res2=acf(cuad.res.arima22,main='ACF Residuales al cuadrado',lag.max=100,ylim=c(- 0.5,1))
pacf.res2=pacf(cuad.res.arima22,main='PACF Residuales al cuadrado',lag.max=100,ylim=c(-0.5,1))

## utilizamos los comandos ugarchspec y ugarchfit, que son rutinas para generar un modelo GARCH(1,1) con una especificaci�n ARMA(1,1) en la media ##
spec = ugarchspec()
fit = ugarchfit(data = ipc[,1], spec = spec)
fit

## Con el modelo estimado es posible realizar una predicci�n de los rendimientos para los siguientes diez per�odos, para lo cual utilizamos el comando fit ##
fit = ugarchfit(data = ipc[,1], spec = spec,out.sample=10)
forc=ugarchforecast(fit, n.ahead=10)

## Gr�ficamos nuestros resultados con el comando plot y se abren las siguientes opciones de gr�ficas ##
plot(forc)

## la primera opci�n y la cuarta con la predicci�n no condicional, nos permiten obtener el rendimiento futuro.
spec2=ugarchspec(variance.model = list(model = "sGARCH", garchOrder = c(1, 1), 
submodel = NULL, external.regressors = NULL, variance.targeting = FALSE), 
mean.model = list(armaOrder = c(2, 2), include.mean = TRUE, archm = FALSE, 
archpow = 1, arfima = FALSE, external.regressors = NULL, archex = FALSE), 
distribution.model = "norm", start.pars = list(), fixed.pars = list())

## generamos un objeto ##
fit = ugarchfit(data = ipc[,1], spec = spec2)

## llamamos al objeto##
fit
