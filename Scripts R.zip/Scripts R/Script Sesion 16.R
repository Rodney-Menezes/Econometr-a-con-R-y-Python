#===========================================
#===========================================
# Curso: Econometr�a aplicada con R y Python
#===========================================
#===========================================
#Instructor: Jose Rodney Menezes De la Cruz
#===========================================
# Sesion 16. Modelos Panel
#-----------------------------
#-----------------------------


#Instalar paquetes
install.packages("plm")
library(plm)
library(urca) 
library(car) 

# Lectura de la base de datos
file.choose()
ruta <- "C:\\Users\\Cliente\\Desktop\\Econometria R y Py\\Bases de Datos\\BaseDatos_Sesion_16\\InfDesmp.csv"

InfDesmp <- read.csv(ruta)

#Resumen de datos
summary(InfDesmp) 

#Matrices de diagramas de dispersi�n 1995-2010 
scatterplotMatrix(~INF+U_UN+CETES28, reg.line=lm, smooth=FALSE,
                  spread=FALSE,span=0.5, diagonal = 'density', data=InfDesmp, Periodo < 2001) 


# Estimaci�n Pool 
modelo.pool <- plm(INF~U_UN+CETES28, data = InfDesmp, index = c("Periodo", "Ciudad"), model = "pooling")
summary(modelo.pool) 

#Estimaci�n con Efectos Fijos
modelo.ef <- plm(INF~U_UN+CETES28, index = c("Periodo", "Ciudad"), data = InfDesmp, model = "within") 
summary(modelo.ef)

#Modelo de Efectos Aleatorios
modelo.ea <- plm(INF ~ U_UN+CETES28, index = c("Periodo", "Ciudad"), data = InfDesmp, model =
                     "random",random.method="amemiya") 
summary(modelo.ea) 


#Elecci�n de modelos alternativos

#Modelo de efectos fijos (ef) versus el modelo Pool (pool)
pooltest(modelo.pool, modelo.ef)

#Test de Hausman 
phtest(modelo.ea, modelo.ef)

#Consideraciones finales sobre los resultados 
#---------------------------------------------
#Con el objetivo de probar en el nivel m�s general la hip�tesis sobre desempleo e
#inflaci�n, en este trabajo se estimaron modelos panel con el paquete  plm del
#software R en sus tres especificaciones  alternativas (pool,  efectos fijos o
#aleatorios),    Con las pruebas pooling y de Hausman se encontr� que el modelo
#pool es consistente con respeto a los modelos de efectos fijos y aleatorio y de
#acuerdo a los resultados econom�tricos se concluy� que tanto la tasa de
#desempleo bajo el mecanismo NAIRU como la tasa de inter�s,   tienen un efecto
#positivo y homog�neo sobre el proceso inflacionario de las ciudades  para el
#periodo 1995-2010.
